# Getting started

## First of all, Welcome!

### Install

Install the components
```
npm install ng2-file-upload --save
```
